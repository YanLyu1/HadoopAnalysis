package HW4.Part5;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class AverageMapper extends Mapper<LongWritable, Text, IntWritable, AverageWritable>{

	private IntWritable year = new IntWritable();
	private final static SimpleDateFormat frmt = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
	private Calendar cal = Calendar.getInstance();
	@Override
	protected void map(LongWritable key, Text value,
			Mapper<LongWritable, Text, IntWritable, AverageWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.map(key, value, context);
		//skip the first line
		if(key.get() == 0)
			return;
		//date index == 2, stock_price_adj_close  index = 8
		String[] tokens = value.toString().split(",");
		String date = tokens[2];
		try {
			Date dateType = frmt.parse(date);
			cal.setTime(dateType);
			int y = cal.get(Calendar.YEAR);
			year.set(y);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		float price = Float.parseFloat(tokens[8]);
		AverageWritable aw = new AverageWritable();
		aw.setAverage(price);
		aw.setCount(1);
		context.write(year, aw);
	}

}









