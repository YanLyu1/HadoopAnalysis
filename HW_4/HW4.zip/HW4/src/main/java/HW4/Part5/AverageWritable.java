package HW4.Part5;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class AverageWritable implements Writable, WritableComparable<AverageWritable>{

	//fields
	private float average;
	private float count;
	
	public AverageWritable() {
		super();
	}
	
	public AverageWritable(float average, float count) {
		super();
		this.average = average;
		this.count = count;
	}
	public float getCount() {
		return count;
	}

	public void setCount(float count) {
		this.count = count;
	}

	public float getAverage() {
		return average;
	}

	public void setAverage(float average) {
		this.average = average;
	}

	public void readFields(DataInput input) throws IOException {
		// TODO Auto-generated method stub
		average = input.readFloat();
		count = input.readFloat();
	}

	public void write(DataOutput output) throws IOException {
		// TODO Auto-generated method stub
		output.writeFloat(average);
		output.writeFloat(count);
	}
	
	public String toString() {
		return "average: " + average + ", count: " + count;
	}

	public int compareTo(AverageWritable that) {
		// TODO Auto-generated method stub
		double result = count - that.getCount();
		if(result == 0.0){
			result = average - that.getAverage();
		}
		return (result < 0.0 ? -1 : (result == 0.0 ? 0 : 1));
	}

}
