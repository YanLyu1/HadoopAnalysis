package HW4.Part5;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class AverageReducer extends Reducer<IntWritable, AverageWritable, IntWritable, AverageWritable>{

	private AverageWritable result = new AverageWritable();
	@Override
	protected void reduce(IntWritable key, Iterable<AverageWritable> values,
			Reducer<IntWritable, AverageWritable, IntWritable, AverageWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.reduce(arg0, arg1, arg2);
		float sum = 0;
		float count = 0;
		
		//iterate through all value for this key
		for(AverageWritable val : values) {
			sum += val.getAverage() * val.getCount();
			count += val.getCount();
		}
		
		result.setAverage(sum / count);
		result.setCount(count);
		context.write(key, result);
	}
}
