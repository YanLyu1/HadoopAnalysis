package HW4.Part6;

import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TopMapper extends Mapper<IntWritable, Text, IntWritable, Text>{

	
	private TreeMap<Integer, Text> repToRecordMap = new TreeMap<Integer, Text>();
	@Override
	protected void map(IntWritable key, Text value, Mapper<IntWritable, Text, IntWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.map(key, value, context);
		
		repToRecordMap.put(key.get(), value);
		if(repToRecordMap.size() > 10) {
			repToRecordMap.remove(repToRecordMap.firstKey());
		}
	}

	@Override
	protected void cleanup(Mapper<IntWritable, Text, IntWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
	
		while(!repToRecordMap.isEmpty()) {
			Integer k = repToRecordMap.lastKey();
			Text v = repToRecordMap.get(repToRecordMap.lastKey());
			context.write(new IntWritable(k), new Text(v));
			repToRecordMap.remove(repToRecordMap.lastKey());
		}
	}
}
