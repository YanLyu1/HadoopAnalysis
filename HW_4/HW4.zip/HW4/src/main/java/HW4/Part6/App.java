package HW4.Part6;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.map.InverseMapper;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.chain.ChainMapper;
import org.apache.hadoop.mapreduce.lib.chain.ChainReducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ) throws IOException, ClassNotFoundException, InterruptedException{
//        System.out.println( "Hello World!" );
    	Configuration conf = new Configuration();
    	Job job = Job.getInstance(conf, "Top 10 IP Address");
    	
    	//set driver class
    	job.setJarByClass(App.class);
    	
    	//set input output
    	job.setInputFormatClass(TextInputFormat.class);
    	job.setOutputFormatClass(TextOutputFormat.class);
    	
    	Configuration map1 = new Configuration(false);
    	ChainMapper.addMapper(job,
    						  CountMapper.class,
    						  LongWritable.class,
    						  Text.class,
    						  Text.class,
    						  IntWritable.class,
    						  map1);
    	
    	Configuration reduce1 = new Configuration(false);
    	ChainReducer.setReducer(job,
    						    CountReducer.class,
    						    Text.class,
    						    IntWritable.class,
    						    Text.class,
    						    IntWritable.class,
    						    reduce1);
    	
    	Configuration map2 = new Configuration(false);
    	ChainReducer.addMapper(job,
    						   InverseMapper.class,
    						   Text.class,
    						   IntWritable.class,
    						   IntWritable.class,
    						   Text.class,
    						   map2);
    	
    	Configuration map3 = new Configuration(false);
    	ChainReducer.addMapper(job, 
    						   TopMapper.class,
    						   IntWritable.class,
    						   Text.class,
    						   IntWritable.class,
    						   Text.class,
    						   map3);
    	
    	Path input = new Path(args[0]);
    	Path output = new Path(args[1]);
//    	Path input = new Path("/logs/access.log");
//		Path output = new Path("/HW4/Part6/Chain/Result");
		
    	FileInputFormat.addInputPath(job, input);
    	FileOutputFormat.setOutputPath(job, output);
    	
    	FileSystem hdfs = FileSystem.get(conf);
		if(hdfs.exists(output)){
			hdfs.delete(output, true);
		}
		
    	job.waitForCompletion(true);
    }
}
