package HW4.Part3_2;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TripleReducer extends Reducer<Text, OutputWritable, Text, OutputWritable>{

	@Override
	protected void reduce(Text key, Iterable<OutputWritable> values,
			Reducer<Text, OutputWritable, Text, OutputWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		int max_stock_volume = 0;
		int min_stock_volume = Integer.MAX_VALUE;
		String max_volume_date = "";
		String min_volume_date = "";
		double max_price = 0.0;
		for(OutputWritable mow : values) {
//			String date = mow.getDate();
			int stock_volume1 = mow.getMax_stock_volume();
			int stock_volume2 = mow.getMin_stock_volume();
			double price = mow.getStock_price_adj_close();
			if(stock_volume1 > max_stock_volume) {
				max_stock_volume = stock_volume1;
				max_volume_date = mow.getMaxDate();
			}
			
			if(stock_volume2 < min_stock_volume) {
				min_stock_volume = stock_volume2;
				min_volume_date = mow.getMinDate();
			}
			
			max_price = Math.max(max_price, price);
		}
		
		OutputWritable row = new OutputWritable(max_volume_date, 
												max_stock_volume,
												min_volume_date, 
												min_stock_volume,
												max_price);
		context.write(key, row);
	}
}
