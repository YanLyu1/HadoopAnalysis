package HW4.Part3_2;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class OutputWritable implements Writable, WritableComparable<OutputWritable>{
	
	private String maxDate;
	private String minDate;
	private int max_stock_volume;
	private int min_stock_volume;
	private double stock_price_adj_close;
	
	public OutputWritable(){
		super();
	}
	
	public OutputWritable(String maxDate, int max_stock_volume, String minDate, int min_stock_volume, double stock_price_adj_close) {
		super();
		this.maxDate = maxDate;
		this.max_stock_volume = max_stock_volume;
		this.minDate = minDate;
		this.min_stock_volume = min_stock_volume;
		this.stock_price_adj_close = stock_price_adj_close;
	}

	public String getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(String maxDate) {
		this.maxDate = maxDate;
	}

	public String getMinDate() {
		return minDate;
	}

	public void setMinDate(String minDate) {
		this.minDate = minDate;
	}

	public int getMax_stock_volume() {
		return max_stock_volume;
	}

	public void setMax_stock_volume(int max_stock_volume) {
		this.max_stock_volume = max_stock_volume;
	}

	public int getMin_stock_volume() {
		return min_stock_volume;
	}

	public void setMin_stock_volume(int min_stock_volume) {
		this.min_stock_volume = min_stock_volume;
	}

	public double getStock_price_adj_close() {
		return stock_price_adj_close;
	}

	public void setStock_price_adj_close(double stock_price_adj_close) {
		this.stock_price_adj_close = stock_price_adj_close;
	}

	public void readFields(DataInput input) throws IOException {
		// TODO Auto-generated method stub
		maxDate = input.readUTF();
		max_stock_volume = input.readInt();
		minDate = input.readUTF();
		min_stock_volume = input.readInt();
		stock_price_adj_close = input.readDouble();
	}

	public void write(DataOutput output) throws IOException {
		// TODO Auto-generated method stub
		output.writeUTF(maxDate);
		output.writeInt(max_stock_volume);
		output.writeUTF(minDate);
		output.writeInt(min_stock_volume);
		output.writeDouble(stock_price_adj_close);
	}

	public int compareTo(OutputWritable that) {
		// TODO Auto-generated method stub
		
		double result = this.getStock_price_adj_close() - that.getStock_price_adj_close();
		if(result == 0.0){
			result = this.getMax_stock_volume() - that.getMax_stock_volume();
		}
		return (result < 0.0 ? -1 : (result == 0.0 ? 0 : 1));
	}

	public String toString() {
//		return this.getDate() + ", " +this.getStock_volume() + ", " + this.getStock_price_adj_close();
		return "max date is: " + this.getMaxDate() + " , min date is : " + this.getMinDate() + " , max price is : " + this.getStock_price_adj_close();
	}

}
