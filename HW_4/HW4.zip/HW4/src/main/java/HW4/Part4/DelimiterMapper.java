package HW4.Part4;

import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

public class DelimiterMapper extends Mapper<LongWritable, Text, Text, Text>{

	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.map(key, value, context);
		if(key.get() == 0)
			return;
		String[] tokens = value.toString().split(",");
		String symbol = tokens[1];
		String date = tokens[2];
		int stock_volume = Integer.parseInt(tokens[7]);
		double stock_price_adj_close = Double.parseDouble(tokens[8]);
//		String output = date + "," + stock_volume + "," + stock_price_adj_close;
		//max date, max volume, min date, min volume, price
		String output = date + "," + stock_volume + "," + date + "," + stock_volume + "," + stock_price_adj_close;
		context.write(new Text(symbol), new Text(output));
	}
}
