package HW4.Part4;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class DelimiterReducer extends Reducer<Text, Text, Text, Text>{

	@Override
	protected void reduce(Text key, Iterable<Text> values, Reducer<Text, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.reduce(arg0, arg1, arg2);

		//get the result arguments
		int max_stock_volume = 0;
		int min_stock_volume = Integer.MAX_VALUE;
		String max_volume_date = "";
		String min_volume_date = "";
		double max_price = 0.0;
		
		//max date, max volume, min date, min volume, price
		for(Text value : values) {
			String[] tokens = value.toString().split(",");
//			String date = tokens[0];
			int stock_volume1 = Integer.parseInt(tokens[1]);
			int stock_volume2 = Integer.parseInt(tokens[3]);
			double price = Double.parseDouble(tokens[4]);
			
			if(stock_volume1 > max_stock_volume) {
				max_stock_volume = stock_volume1;
				max_volume_date = tokens[0];
			}
			
			if(stock_volume2 < min_stock_volume) {
				min_stock_volume = stock_volume2;
				min_volume_date = tokens[2];
			}
			
			max_price = Math.max(max_price, price);
		}

//		String result = "max date is : " + max_volume_date + ", min date is : " + min_volume_date + ", max price is : " + max_price;
		String result = max_volume_date + "," + max_stock_volume + "," + min_volume_date + "," +min_stock_volume + "," + max_price;
		context.write(key, new Text(result));
	}
	
}
