package HW4.Part4;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ) throws IOException, ClassNotFoundException, InterruptedException{
//        System.out.println( "Hello World!" );
    	Configuration conf = new Configuration();
    	Job job = Job.getInstance(conf, "Deliniter MapReduce");
    	
    	//set driver class
    	job.setJarByClass(App.class);
    	
    	//set mapper output
    	job.setMapOutputKeyClass(Text.class);
    	job.setMapOutputValueClass(Text.class);
    	
    	
    	//set input output
    	job.setInputFormatClass(TextInputFormat.class);
    	job.setOutputFormatClass(TextOutputFormat.class);
    	
    	//output key and value
    	job.setOutputKeyClass(Text.class);
    	job.setOutputValueClass(Text.class);
    	
    	//set map reduce
    	job.setMapperClass(DelimiterMapper.class);
    	job.setReducerClass(DelimiterReducer.class);
    	job.setCombinerClass(DelimiterReducer.class);
    	
    	Path input = new Path(args[0]);
    	Path output = new Path(args[1]);
//    	Path input = new Path("/HW4/Part2/NYSE/NYSE_daily_prices_A.csv");
//		Path output = new Path("/HW4/Part4/Result");
		
    	FileInputFormat.addInputPath(job, input);
    	FileOutputFormat.setOutputPath(job, output);
    	
    	FileSystem hdfs = FileSystem.get(conf);
		if(hdfs.exists(output)){
			hdfs.delete(output, true);
		}
		
    	job.waitForCompletion(true);
    }
}
