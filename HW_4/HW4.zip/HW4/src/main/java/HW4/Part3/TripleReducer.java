package HW4.Part3;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TripleReducer extends Reducer<Text, MapperOutputWritable, Text, ReducerOutputWritable>{

	@Override
	protected void reduce(Text key, Iterable<MapperOutputWritable> values,
			Reducer<Text, MapperOutputWritable, Text, ReducerOutputWritable>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		int max_stock_volume = 0;
		int min_stock_volume = Integer.MAX_VALUE;
		String max_volume_date = "";
		String min_volume_date = "";
		double max_price = 0.0;
		for(MapperOutputWritable mow : values) {
//			String date = mow.getDate();
			int stock_volume = mow.getStock_volume();
			double price = mow.getStock_price_adj_close();
			if(stock_volume > max_stock_volume) {
				max_stock_volume = stock_volume;
				max_volume_date = mow.getDate();
			}
			
			if(stock_volume < min_stock_volume) {
				min_stock_volume = stock_volume;
				min_volume_date = mow.getDate();
			}
			
			max_price = Math.max(max_price, price);
		}
		
		ReducerOutputWritable row = new ReducerOutputWritable(max_volume_date, min_volume_date, max_price);
		context.write(key, row);
	}
}
