package HW4.Part3;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class MapperOutputWritable implements Writable, WritableComparable<MapperOutputWritable>{
	
	private String date;
	private int stock_volume;
	private double stock_price_adj_close;
	
	public MapperOutputWritable(){
		super();
	}
	
	public MapperOutputWritable(String date, int stock_volume, double stock_price_adj_close) {
		super();
		this.date = date;
		this.stock_volume = stock_volume;
		this.stock_price_adj_close = stock_price_adj_close;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getStock_volume() {
		return stock_volume;
	}

	public void setStock_volume(int stock_volume) {
		this.stock_volume = stock_volume;
	}

	public double getStock_price_adj_close() {
		return stock_price_adj_close;
	}

	public void setStock_price_adj_close(double stock_price_adj_close) {
		this.stock_price_adj_close = stock_price_adj_close;
	}

	public void readFields(DataInput input) throws IOException {
		// TODO Auto-generated method stub
		date = input.readUTF();
		stock_volume = input.readInt();
		stock_price_adj_close = input.readDouble();
	}

	public void write(DataOutput output) throws IOException {
		// TODO Auto-generated method stub
		output.writeUTF(date);
		output.writeInt(stock_volume);
		output.writeDouble(stock_price_adj_close);
	}

	public int compareTo(MapperOutputWritable that) {
		// TODO Auto-generated method stub
		
		double result = this.getStock_price_adj_close() - that.getStock_price_adj_close();
		if(result == 0.0){
			result = this.getStock_volume() - that.getStock_volume();
		}
		return (result < 0.0 ? -1 : (result == 0.0 ? 0 : 1));
	}

	public String toString() {
		return this.getDate() + ", " +this.getStock_volume() + ", " + this.getStock_price_adj_close();
	}

}
