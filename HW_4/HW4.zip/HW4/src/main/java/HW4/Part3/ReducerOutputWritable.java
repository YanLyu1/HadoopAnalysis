package HW4.Part3;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class ReducerOutputWritable implements Writable, WritableComparable<ReducerOutputWritable>{
	private String maxDate;
	private String minDate;
	private double maxPrice;
	
	public ReducerOutputWritable() {
		super();
	}
	
	public ReducerOutputWritable(String maxDate, String minDate, double maxPrice) {
		super();
		this.maxDate = maxDate;
		this.minDate = minDate;
		this.maxPrice = maxPrice;
	}
	
	public String getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(String maxDate) {
		this.maxDate = maxDate;
	}

	public String getMinDate() {
		return minDate;
	}

	public void setMinDate(String minDate) {
		this.minDate = minDate;
	}

	public double getMaxPrice() {
		return maxPrice;
	}

	public void setMaxPrice(double maxPrice) {
		this.maxPrice = maxPrice;
	}

	public void readFields(DataInput input) throws IOException {
		// TODO Auto-generated method stub
		maxDate = input.readUTF();
		minDate = input.readUTF();
		maxPrice = input.readDouble();
	}

	public void write(DataOutput output) throws IOException {
		// TODO Auto-generated method stub
		output.writeUTF(maxDate);
		output.writeUTF(minDate);
		output.writeDouble(maxPrice);
	}

	public int compareTo(ReducerOutputWritable that) {
		// TODO Auto-generated method stub
		int result = this.maxDate.compareTo(that.maxDate);
		if(result == 0) {
			result = this.minDate.compareTo(that.minDate);
		}
		return (result < 0 ? -1 : (result == 0 ? 0 : 1));
	}
	
	public String toString() {
		String result = "max date is : " + this.getMaxDate() + ", min date is : " + this.getMinDate() + ", max price is : " + this.getMaxPrice();
		return result;
	}

}
