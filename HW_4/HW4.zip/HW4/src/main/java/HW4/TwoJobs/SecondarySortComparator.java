package HW4.TwoJobs;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class SecondarySortComparator extends WritableComparator{

	public SecondarySortComparator() {
		super(CompositeKeyWritable.class, true);
	}
	
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		CompositeKeyWritable c1 = (CompositeKeyWritable) a;
		CompositeKeyWritable c2 = (CompositeKeyWritable) b;
		int count1 = c1.getCount();
		int count2 = c2.getCount();
		int result = count2 - count1;
//		return -1 * result;
		return (result < 0 ? -1 : (result == 0 ? 0 : 1));
	}
}
