package HW4.TwoJobs;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class NaturalPartitioner extends Partitioner<CompositeKeyWritable, Text>{

	@Override
	public int getPartition(CompositeKeyWritable key, Text value, int numPartitions) {
		// TODO Auto-generated method stub
		
		return key.getNaturalKey().hashCode() % numPartitions;
	}
}
