package HW4.TwoJobs;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.Job;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException, ClassNotFoundException, InterruptedException
    {
//        System.out.println( "Hello World!" );
    	Configuration conf = new Configuration();
    	Job job1 = Job.getInstance(conf, "Count Visit Times");
    	
    	job1.setJarByClass(App.class);
    	job1.setInputFormatClass(TextInputFormat.class);
    	job1.setOutputFormatClass(TextOutputFormat.class);
    	
    	job1.setOutputKeyClass(Text.class);
        job1.setOutputValueClass(IntWritable.class);
        
        job1.setMapperClass(CountMapper.class);
        job1.setReducerClass(CountReducer.class);
        
//        Path input = new Path("/logs/access.log");
//        Path output = new Path("/HW4/Part6/CountResult");
        
        Path input = new Path(args[0]);
        Path output = new Path("/HW4/Part6/CountResult");
        FileInputFormat.addInputPath(job1, input);
        FileOutputFormat.setOutputPath(job1, output);
        
        FileSystem hdfs = FileSystem.get(conf);
		if(hdfs.exists(output)){
			hdfs.delete(output, true);
		}
		
        job1.waitForCompletion(true);
        
        Job job2 = Job.getInstance(conf, "Get top 10");
        job2.setJarByClass(App.class);
        job2.setInputFormatClass(KeyValueTextInputFormat.class);
    	job2.setOutputFormatClass(TextOutputFormat.class);
    	job2.setMapOutputKeyClass(CompositeKeyWritable.class);
    	job2.setMapOutputValueClass(Text.class);
    	job2.setPartitionerClass(NaturalPartitioner.class);
    	job2.setGroupingComparatorClass(GroupComparator.class);
    	job2.setSortComparatorClass(SecondarySortComparator.class);
    	job2.setOutputKeyClass(IntWritable.class);
    	job2.setOutputValueClass(Text.class);
    	job2.setMapperClass(TopMapper.class);
    	job2.setReducerClass(TopReducer.class);
    	Path input2 = new Path("/HW4/Part6/CountResult/part-*");
//    	Path output2 = new Path("/HW4/Part6/Result");
    	Path output2 = new Path(args[1]);
        FileInputFormat.setInputPaths(job2, input2);
        FileOutputFormat.setOutputPath(job2, output2);
        
//        FileSystem hdfs = FileSystem.get(conf);
		if(hdfs.exists(output2)){
			hdfs.delete(output2, true);
		}
        job2.waitForCompletion(true);
    }
}
