package HW4.TwoJobs;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

//input : ({" ", count}, ipaddress)
//output: (count, ipaddress)
public class TopReducer extends Reducer<CompositeKeyWritable, Text, IntWritable, Text >{

	@Override
	protected void reduce(CompositeKeyWritable key, Iterable<Text> values,
			Reducer<CompositeKeyWritable, Text, IntWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.reduce(arg0, arg1, arg2);
		
		for(int i = 0; i < 10; i++) {
			Text value = values.iterator().next();
			context.write(new IntWritable(key.getCount()),value);
		}
	}
}
