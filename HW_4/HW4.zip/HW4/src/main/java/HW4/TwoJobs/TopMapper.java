package HW4.TwoJobs;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TopMapper extends Mapper<Text, Text, CompositeKeyWritable, Text>{

	@Override
	protected void map(Text key, Text value,
			Mapper<Text, Text, CompositeKeyWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
//		super.map(key, value, context);
//		String IPAddress = key.toString();
//		int count = value.get();
		int count = Integer.parseInt(value.toString());
		CompositeKeyWritable ckw = new CompositeKeyWritable();
		ckw.setNaturalKey(" ");
		ckw.setCount(count);
		context.write(ckw, key);
	}
}
