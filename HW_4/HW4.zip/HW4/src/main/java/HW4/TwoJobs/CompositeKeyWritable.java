package HW4.TwoJobs;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class CompositeKeyWritable implements Writable, WritableComparable <CompositeKeyWritable>{
	
	private String naturalKey;
	private int count;
	
	public CompositeKeyWritable() {
		super();
	}


	public CompositeKeyWritable(String naturalKey, int count) {
		super();
		this.naturalKey = naturalKey;
		this.count = count;
	}
	
	public String getNaturalKey() {
		return naturalKey;
	}


	public void setNaturalKey(String naturalKey) {
		this.naturalKey = naturalKey;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}


	//in descending order
	public int compareTo(CompositeKeyWritable that) {
		// TODO Auto-generated method stub
		int result = that.getCount() - this.getCount();
		return (result < 0 ? -1 : (result == 0 ? 0 : 1));
	}

	public void readFields(DataInput input) throws IOException {
		// TODO Auto-generated method stub
		naturalKey = input.readUTF();
		count = input.readInt();
	}

	public void write(DataOutput output) throws IOException {
		// TODO Auto-generated method stub
		output.writeUTF(naturalKey);
		output.writeInt(count);
	}
	
	public String toString() {
		String result = "count is: " + count;
		return result;
	}

}
