package HW4.TwoJobs;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class CountMapper extends Mapper<LongWritable, Text, Text, IntWritable>{

	Text word = new Text();
	IntWritable one = new IntWritable(1);
	//number of times each IP accesses the website
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString();
		String[] tokens = line.split("\\s+");
		String ipAddress = tokens[0];
		word.set(ipAddress);
		context.write(word, one);
	}
}
