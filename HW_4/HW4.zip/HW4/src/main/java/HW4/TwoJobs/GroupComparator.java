package HW4.TwoJobs;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class GroupComparator extends WritableComparator {
	
	public GroupComparator() {
		super(CompositeKeyWritable.class, true);
	}
	
	@Override
	public int compare(WritableComparable a, WritableComparable b) {
		CompositeKeyWritable ckw1 = (CompositeKeyWritable) a;
		CompositeKeyWritable ckw2 = (CompositeKeyWritable) b;
		int result = ckw1.getNaturalKey().compareTo(ckw2.getNaturalKey());
		return result;
	}

}

